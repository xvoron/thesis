# VUT-template
Neoficialni VUT šablona závěrečných praci, vychází ze směrnic FSI, ale dogmaticky se jim nepodřizuje (např. má menší okraje).

# Overleaf
* Klon šablony existuje také na stránce projektu Overleaf: [VUT Template](https://www.overleaf.com/read/tpzfxwqztqxd)
